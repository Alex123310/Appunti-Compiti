//CREA LA PARTIZIONE
void CreatePartition(Partizione partizioni[]); 
//ALLOCA IL PROCESSO
int Alloca_Processo(Partizione part[], int DimensioneProesso); 
//STAMPA LA PARTIZIONE A SCHERMO
void VisualizzaPartizione(Partizione part[]);
