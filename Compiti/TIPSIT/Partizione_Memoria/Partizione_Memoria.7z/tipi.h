typedef struct 
{
    int IndBase; 
    int Dim; 
    int Occ; 
} Partizione;